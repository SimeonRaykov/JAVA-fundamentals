package CreatingConstructors;

public class Person {

    private String name;
    private int age;
    public static final String invalidName = "No name";
    public static final int invalidAge = 1;

    public Person() {
        this.name = Person.invalidName;
        this.age = Person.invalidAge;
    }

    public Person(int num) {
        this.name = Person.invalidName;
        this.age = num;
    }

    public Person(String name, int age) {
        this(age);
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
